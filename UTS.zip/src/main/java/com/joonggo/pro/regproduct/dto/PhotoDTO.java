package com.joonggo.pro.regproduct.dto;

import lombok.Data;

@Data
public class PhotoDTO {
	private int 		photono;
	private int 		bno;
	private String 		pphotoname;
	private String 		pphotonname;
	private String 		pphotolocation;
}
