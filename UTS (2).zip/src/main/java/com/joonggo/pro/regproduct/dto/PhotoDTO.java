package com.joonggo.pro.regproduct.dto;

public class PhotoDTO {
	private int 		photono;
	private int 		bno;
	private String 		pphotoname;
	private String 		pphotolocation;
}
